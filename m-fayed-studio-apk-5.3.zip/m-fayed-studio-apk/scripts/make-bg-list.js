// بيعمل www/backgrounds/list.json لوحده من الصور اللي في الفولدر (jpg / png / webp)
const fs=require('fs'),path=require('path');
const D=path.join(__dirname,'..','www','backgrounds');
fs.mkdirSync(D,{recursive:true});
const l=fs.readdirSync(D).filter(f=>/\.(jpe?g|png|webp)$/i.test(f)).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
fs.writeFileSync(path.join(D,'list.json'),JSON.stringify(l,null,1));
console.log('✔ '+l.length+' خلفية في القائمة');
