// بينزّل المصحف كامل (رسم عثماني + نص بسيط للتعرف على الصوت) وقت البناء على GitHub
// عشان التطبيق يشتغل من غير ما تنزّل كل سورة لوحدها.
const fs=require('fs'),path=require('path');
const OUT=path.join(__dirname,'..','www','quran');
const API='https://api.alquran.cloud/v1/quran/';
const get=async u=>{let e;for(let i=0;i<4;i++){try{const r=await fetch(u);if(r.ok){const j=await r.json();if(j&&j.data&&j.data.surahs&&j.data.surahs.length===114)return j}}catch(x){e=x}await new Promise(r=>setTimeout(r,2000*(i+1)))}throw new Error('تعذر تحميل '+u+(e?' — '+e.message:''))};
(async()=>{
  fs.mkdirSync(OUT,{recursive:true});
  const u=await get(API+'quran-uthmani'),o={};let tot=0;
  u.data.surahs.forEach(s=>{const a=s.ayahs.map(x=>x.text);
    if(s.number!==1&&s.number!==9)a[0]=a[0].replace(/^\S+\s+\S+\s+\S+\s+\S+\s*/,'');   // شيل البسملة من أول آية (التطبيق بيضيفها لوحده)
    o[s.number]={name:s.name,ayat:a};tot+=a.length});
  if(tot!==6236)throw new Error('عدد الآيات غير متوقع: '+tot);
  fs.writeFileSync(path.join(OUT,'quran-uthmani.json'),JSON.stringify(o));
  const m=await get(API+'quran-simple');
  fs.writeFileSync(path.join(OUT,'quran-simple.json'),JSON.stringify(m.data.surahs.map(s=>s.ayahs.map(a=>a.text))));
  console.log('✔ المصحف اتحفظ جوه www/quran ('+tot+' آية)');
})().catch(e=>{console.error('✘',e.message);process.exit(1)});
