package com.mfayed.studio;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@CapacitorPlugin(name = "MFNative")
public class MFNativePlugin extends Plugin {
    private final Map<String, OutputStream> outs = new HashMap<>();
    private final Map<String, Uri> uris = new HashMap<>();
    private final Map<String, File> files = new HashMap<>();

    // ===== اختيار صوت من برنامج الصوت/الموسيقى بتاع الجهاز =====
    @PluginMethod
    public void pickAudio(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(call, i, "pickDone");
        } catch (Exception e) {
            try {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("audio/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(call, i, "pickDone");
            } catch (Exception e2) {
                call.reject("no picker");
            }
        }
    }

    @ActivityCallback
    private void pickDone(PluginCall call, ActivityResult r) {
        if (call == null) return;
        if (r.getResultCode() != Activity.RESULT_OK || r.getData() == null || r.getData().getData() == null) {
            call.reject("cancel");
            return;
        }
        try {
            Uri u = r.getData().getData();
            ContentResolver cr = getContext().getContentResolver();
            String name = "audio";
            Cursor c = cr.query(u, null, null, null, null);
            if (c != null) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (ix >= 0 && c.moveToFirst()) name = c.getString(ix);
                c.close();
            }
            File f = new File(getContext().getCacheDir(), "pick_" + System.currentTimeMillis() + "_" + name.replaceAll("[^A-Za-z0-9._-]", "_"));
            InputStream in = cr.openInputStream(u);
            OutputStream out = new FileOutputStream(f);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            JSObject o = new JSObject();
            o.put("path", f.getAbsolutePath());
            o.put("name", name);
            call.resolve(o);
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    // ===== حفظ الفيديو في المعرض (Movies/M-Fayed) =====
    @PluginMethod
    public void saveBegin(PluginCall call) {
        try {
            String name = call.getString("name", "m-fayed.mp4").replaceAll("[\\\\/:*?\"<>|]", "_");
            String mime = call.getString("mime", "video/mp4");
            String id = UUID.randomUUID().toString();
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
                v.put(MediaStore.Video.Media.MIME_TYPE, mime);
                v.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/M-Fayed");
                v.put(MediaStore.Video.Media.IS_PENDING, 1);
                Uri u = getContext().getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
                if (u == null) throw new Exception("MediaStore insert failed");
                OutputStream os = getContext().getContentResolver().openOutputStream(u);
                if (os == null) throw new Exception("openOutputStream failed");
                outs.put(id, os);
                uris.put(id, u);
            } else {
                File d = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "M-Fayed");
                d.mkdirs();
                File f = new File(d, name);
                outs.put(id, new FileOutputStream(f));
                files.put(id, f);
            }
            JSObject o = new JSObject();
            o.put("id", id);
            call.resolve(o);
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void saveChunk(PluginCall call) {
        try {
            OutputStream o = outs.get(call.getString("id"));
            o.write(Base64.decode(call.getString("data"), Base64.DEFAULT));
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void saveFinish(PluginCall call) {
        try {
            String id = call.getString("id");
            OutputStream o = outs.remove(id);
            o.close();
            Uri u = uris.remove(id);
            if (u != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContext().getContentResolver().update(u, v, null, null);
            }
            File f = files.remove(id);
            if (f != null) MediaScannerConnection.scanFile(getContext(), new String[]{f.getAbsolutePath()}, null, null);
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }
}
